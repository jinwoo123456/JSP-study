package fileupload;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
//서블릿 매핑
@WebServlet("/13FileUpload/MultipleProcess.do")
//업로드 제한 용량
@MultipartConfig(
		maxFileSize = 1024 * 1024 * 1,
		maxRequestSize = 1024 * 1024 * 10
		)
public class MultipleProcess extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		try {
			
			//저장 디렉토리의 물리적 경로 얻어오기
			String saveDirectory = getServletContext()
					.getRealPath("/Uploads");
			//멀티 파일 업로드를 위한 함수 호출
			ArrayList<String> listFileName = FileUtil
					.multipleFile(req, saveDirectory);
			//업로드한 파일의 갯수만큼 ㄴ반복하여 파일명을 변경
			for(String originalFileName: listFileName) {
				String savedFileName = FileUtil
						.renameFile(saveDirectory, originalFileName);
			
			}
			Context initContext = new InitialContext();
			DataSource ds = (DataSource) initContext.lookup("java:/comp/env/dbcp_myoracle");
			try(Connection conn = ds.getConnection(){
				for (String originalFileName : listFileName) {
	                String sql = "INSERT INTO myfile (title, cate, ofile, sfile, postdate) VALUES (?, ?, ?, ?, SYSDATE)";

	                String title = req.getParameter("title");
	                String cate = req.getParameter("cate");
	                String ofile2 = req.getParameter("ofile");
	                String sfile = req.getParameter("sfile");
	                String postdate = req.getParameter("postdate");
	                try(PreparedStatement psmt = conn.prepareStatement(sql)){
	                	psmt.setString("냠냠", title);
	                	psmt.setString("냠냠", cate);
	                	psmt.setString("abcs", ofile2);
	                	psmt.setString("냠냠", title);
	                }
					 
				}

			}
			//파일 목록으로 이동한다.
			resp.sendRedirect("FileList.jsp");
		}
		catch (Exception e) {
			e.printStackTrace();
			req.setAttribute("errorMessage", "파일 업로드 오류");
			req.getRequestDispatcher("MultiUploadMain.jsp").forward(req,resp);
		}
	}
}
