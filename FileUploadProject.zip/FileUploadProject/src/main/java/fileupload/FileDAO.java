package fileupload;

import common.JDBConnect;
import jakarta.servlet.ServletContext;
import membership.MemberDTO;

/*
 * DTO (Data TransFer Object)
 * :JSP와 Java 파일간에 데이터를 전달하기 위한 객체로 자바빈 규약에 의해 제작한다.
 * 
 * 자바빈즈 규약 
 * 1.자바빈즈는 기본(default)패키지 이외의 패키지에 속해야한다.
 * 2.멤버변수(속성)의 접근지정자는 private로 선언한다.
 * 3.기본 생성자가 있어야 한다.
 * 4.멤버변수에 접근할 수 있는 getter/setter가 있어야한다.
 * 5.getter
*/
public class FileDAO extends JDBConnect{

		//멤버변수 : member 테이블의 컬럼과 동일하게 생성

		public int idx;
		public String title;
		public String cate;
		public String ofile;
		public String sfile;
		public String postdate = "sysdate";
		 // 두 번째 생성자: ServletContext를 사용하여 연결
	    //생성자2 : application 내장객체를 매개변수로 정의
	   

		 public FileDAO(ServletContext application) {
		        super(application);
		    }
		 
		 
		    // 회원 정보를 조회하는 메소드
		      /*
		       *사용자가 입력한 아이디,패스워드를 통해 회원테이블을 select한 후 
		       *존재하는 회원정보인 경우 DTO객체에 레코드를 저장한 후 반환한다.      
		 *      */    
		    public getDTO() {
		    	 
		        try {
		        	//쿼리문 실행을 위한 prepared 인스턴스 생성;
		            psmt = con.prepareStatement(query);
		            //쿼리문의 인파라미터 설정(아이디와 비번)
		            psmt.setString(1, uid);
		            psmt.setString(2, upass);
		            //쿼리문 실행 및 결과는 ResultSet으로 반환받는다.
		            rs = psmt.executeQuery();
		            //반환된 resultset객체에 정보가 저장되어 있는지 확인

		           
		            	//회원정보가 있다면 DTO 객체에 저장.
		                idx.setId(rs.getInt("1"));
		                title.setPass(rs.getString("pass"));
		                cate.setName(rs.getString(3));
		                ofile.setRegidate(rs.getString(4));
		               sfile.setRegidate(rs.getString(4));
		               postdate.setRegidate(rs.now);
		            }
		        } catch (Exception e) {
		            e.printStackTrace();
		        }
		        //회원정보를 저장한 DTO 객체를 반환한다.
		        return;
		    }
		
		
		
}
