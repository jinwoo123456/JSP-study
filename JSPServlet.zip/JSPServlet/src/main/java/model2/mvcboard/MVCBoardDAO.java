package model2.mvcboard;

import java.sql.PreparedStatement;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import common.DBConnPool;


/*
 * DBCP(커넥션풀)을 통해 oRACLE에 연결하기 위해 상속을 받아 정의한다.
 * */
public class MVCBoardDAO extends DBConnPool {
	
	//기본 생성자를 통해 부모 생성자를 호출
	public MVCBoardDAO() {
		super();
	}

	//게시물의 갯수를 카운트
    public int selectCount(Map<String, Object> map) {
        int totalCount = 0;
        //오라클의 그룹함수는 count()를 사용해서 쿼리문 작성
        String query = "SELECT COUNT(*) FROM mvcboard";
        //매개변수로 전달된 검색어가 있는 경우에만 where절을 동적으로 추가
        if (map.get("searchWord") != null) {
            query += " WHERE " + map.get("searchField") + " LIKE '%" + map.get("searchWord") + "%'";
        }

        try {
        	//Statement 인스턴스 생성(정적 쿼리문 실행)
            stmt = con.createStatement();
            //쿼리문을 실행한 후 결과를 ResultSet으로 반환받는다.
            rs = stmt.executeQuery(query);
            /*
             * count()함수는 조건과 상관없이 항상 결과가 인출되므로
             * if문과 같은 조건절없이 바로 next()함수를 실행할 수 있다.
             * */
            rs.next() ;
               totalCount = rs.getInt(1);
            
        } catch (Exception e) {
            System.out.println("게시물 카운트 중 예외 발생");
            e.printStackTrace();
        }
        return totalCount;
    }

    	//게시판 목록에 출력할 레코드를 인출하기 위한 메서드 정의
    public List<MVCBoardDTO> selectList(Map<String, Object> map) {
    	//오라클에서 인출한 레코드를 저장하기 위한 List 생성
        List<MVCBoardDTO> board = new Vector<MVCBoardDTO>();
        
        //레코드 인출을 위한 쿼리문 작성
        String query = "SELECT * FROM mvcboard";

        //검색어 입력 여부에 따랏허 where 절은 조건부로 추가됌.
        if (map.get("searchWord") != null) {
            query += " WHERE " + map.get("searchField") + " LIKE '%" + map.get("searchWord") + "%'";
        }
        //일렬번호의 내림차순으로 정렬한 후 인출한다.
        query += " ORDER BY idx DESC";
        //게시판을 항상 최근에 작성한 게시물이 상단에 노출되어야 한다.
        
        
        try {
        	//PreparedStateMent 인스턴스 생성
            psmt = con.prepareStatement(query);
            rs = psmt.executeQuery();
            while (rs.next()) {
            	
            	//하느의 레코드를 저장하기 위해 DTO인스턴스 생성
            	MVCBoardDTO dto = new MVCBoardDTO();
            	/*
            	 * ResultSet 인스턴스에서 데이터를 추출할때 멤버변수의 타입에따라
            	 * getString(),getInt(),getDate()로 구분하여 호출한다.
            	 * 이 데이터를 DTO의 setter를 이용해서 저장한다.
            	 * */
                dto.setIdx(rs.getString(1));
                dto.setId(rs.getString(2));
                dto.setTitle(rs.getString(3));
                dto.setContent(rs.getString(4));
                dto.setPostdate(rs.getDate(5));
                dto.setOfile(rs.getString(6));
                dto.setSfile(rs.getString(7));
                dto.setDowncount(rs.getInt(8));
                dto.setVisitcount(rs.getInt(9));
                //레코드가 저장된 DTO를 List에 갯수만큼 추가한다.
                board.add(dto);
            }
        } catch (Exception e) {
            System.out.println("게시물 조회 중 예외 발생");
            e.printStackTrace();
        }
        //마지막으로 인출한 레코드를 저장한 List를 반환한다.
        return board;
    }
    public int insertWrite(MVCBoardDTO dto) {
    	int result = 0;
    	try {
    		String query = "INSERT INTO mvcboard ("
    				+ " idx, id, title, content, ofile, sifle)"
    				+" VALUSE("
    				+" seq_board_num.NEXTVAL,?,?,?,?,?)";
    		
    	}	
    	catch ( Exception e ){
    		System.out.println("게시물 입력 중 예외 발생");
    		e.printStackTrace();
    		
    		
    	}return result;
    	
    }
    public MVCBoardDTO selectView(String idx) {
    	//인출한 레코드를 저장하기 위해 DTO 생성
    	MVCBoardDTO dto = new MVCBoardDTO();
    	String query = "SELECT BO.*, Me.name FROM mvcboard BO"
    			+" INNER JOIN member Me ON BO.id=Me.id"
    			+" WHERE idx=?";
    	 try {
         	//PreparedStateMent 인스턴스 생성
             psmt = con.prepareStatement(query);//쿼리문 준비
             psmt.setString(1, idx);//인파라미터 설정
             rs = psmt.executeQuery();// 쿼리문 실행
             //하나의 게시물을 인출하므로 if문으로 조건에 맞는 게시물이 있는지 확인
             if (rs.next()) {
            	 //결과를 dto 객체에 저장
             	
             	//하느의 레코드를 저장하기 위해 DTO인스턴스 생성
             	
             	/*
             	 * ResultSet 인스턴스에서 데이터를 추출할때 멤버변수의 타입에따라
             	 * getString(),getInt(),getDate()로 구분하여 호출한다.
             	 * 이 데이터를 DTO의 setter를 이용해서 저장한다.
             	 * */
            	 
                 dto.setIdx(rs.getString(1));
                 dto.setId(rs.getString(2));
                 dto.setTitle(rs.getString(3));
                 dto.setContent(rs.getString(4) != null ? rs.getString(4) : "");
                 dto.setPostdate(rs.getDate(5));
                 dto.setOfile(rs.getString(6));
                 dto.setSfile(rs.getString(7));
                 dto.setDowncount(rs.getInt(8));
                 dto.setVisitcount(rs.getInt(9));
                 dto.setVisitcount(rs.getInt(10));
                 //레코드가 저장된 DTO를 List에 갯수만큼 추가한다.
                 
             }
         } catch (Exception e) {
             System.out.println("게시물 상세보기 중 예외 발생");
             e.printStackTrace();
         }
    	 return dto; //결과 반환
    }
    // 주어진 일렬번호에 해당하는 게시물의 조회수를 1 증가시킵니다
    public void updateVisitCount(String idx) {
    	//visitcount 컬럼은 number 타입이므로 산술연산이 가능함.
    	//1을 더한 결과를 컬럼에 재반영하는 형식으로 update 쿼리문 작성.
    	String query = "UPDATE mvcboard SET"
    			+ " visitcount=visitcount+1"
    			+ " WHERE idx=?";
    	try {
    		psmt = con.prepareStatement(query);
    		psmt.setString(1, idx);
    		/*
    		 * 쿼리 실행 시 주로 아래의 두가지 메서드를 사용한다.
    		 * executeQuery() : select 계열의 쿼리문을 실행한다. 반환타입은 resultSet
    		 * executeUpdate() : insert, update ,delete 계열의 쿼리문을 실행한다.
    		 * 반환타입은 int.
    		 * 
    		 * 만약 쿼리 실행 후 별도의 반환값이 필요하지 않다면 위 2개의 메서드 중 어떤것을 사용해도 무방하다
    		 * */
    		psmt.executeQuery();
    	}
    	catch (Exception e) {
    		System.out.println("게시물 조회수 증가 중 예외 발생");
    		e.printStackTrace();
    	}
    }
    public void downCountPlus(String idx) {
    	String sql = "UPDATE mvcboard SET "
    			+ " downcount=downcount+1 "
    			+" WHERE idx=? ";
    	try {
    		psmt = con.prepareStatement(sql);
    		psmt.setString(1, idx);
    		psmt.executeUpdate();
    		
    		
    	}
    	catch (Exception e) {
    		
			// TODO: handle exception
		}
    }
    public int deletePost(String idx) {
    	int result = 0;
    	try {
    		String query = "DELETE FROM mvcboard WHERE idx=?";
    		psmt = con.prepareStatement(query);
    		psmt.setString(1, idx);
    		result = psmt.executeUpdate();
    		
    	}
    	catch (Exception e) {
    		System.out.println("게시물 삭제 중 예외 발생(deletepost");
    		e.printStackTrace();
			// TODO: handle exception
		}
    	return result;
    	
    }
    public int updatePost(MVCBoardDTO dto) {
    	int result = 0;
    	try {
			String query = "UPDATE mvcboard"
					+" SET title=?, content=?, ofile=?, sfile=? "
					+" WHERE idx=? and id=?";
			psmt = con.prepareStatement(query);
			psmt.setString(1, dto.getTitle());
			psmt.setString(2, dto.getContent());
			psmt.setString(3, dto.getOfile());
			psmt.setString(4, dto.getSfile());
			psmt.setString(5, dto.getIdx());
			psmt.setString(6, dto.getId());
			
			result = psmt.executeUpdate();
			
			
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("게시물 수정 중 예외 발생");
			e.printStackTrace();
		}
    	return result;
    }
}
