package model2.mvcboard;

import java.io.IOException;

import fileupload.FileUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import utils.JSFunction;

public class WriteController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();
        if (session.getAttribute("UserId") == null) {
            JSFunction.alertLocation(resp, "로그인 후 이용해주세요.", "../06Session/LoginForm.jsp");
            return;
        }
        req.getRequestDispatcher("/14MVCBoard/Write.jsp").forward(req, resp);
    }

    // 글쓰기 처리
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 로그인 확인 (세션은 일정 시간이 지나면 자동으로 해제되므로 확인이 필요함)
        HttpSession session = req.getSession();
        if (session.getAttribute("UserId") == null) {
            JSFunction.alertLocation(resp, "로그인 후 이용해주세요.", "../06Session/LoginForm.jsp");
            return;
        }

        // 1. 파일 업로드 처리
        String saveDirectory = req.getServletContext().getRealPath("/Uploads"); // 업로드 디렉터리의 물리적 경로 확인
        String originalFileName = ""; // 파일 원본 이름을 저장할 변수

        try {
            // 작성 폼에서 전송한 파일을 업로드 처리
            originalFileName = FileUtil.uploadFile(req, saveDirectory);
        } catch (Exception e) {
            // 파일 업로드 중 문제가 발생한 경우 예외 처리
            JSFunction.alertLocation(resp, "파일 업로드 오류입니다", "../mvcboard/write.do");
            return;
        }

        // 2. 파일 업로드 외 처리
        // 폼값을 dto에 저장
        MVCBoardDTO dto = new MVCBoardDTO();
        dto.setId(session.getAttribute("UserId").toString()); // 세션에서 사용자 ID를 가져와 저장
        dto.setTitle(req.getParameter("title"));              // 제목을 사용자가 입력한 값으로 설정
        dto.setContent(req.getParameter("content"));          // 내용을 사용자가 입력한 값으로 설정

        // 원본 파일명과 저장된 파일 이름 설정
        if (!originalFileName.isEmpty()) { // 파일이 비어있지 않은 경우에만 처리
            String saveFileName = FileUtil.renameFile(saveDirectory, originalFileName); // 파일명 변경
            dto.setOfile(originalFileName); // 원래 파일 이름
            dto.setSfile(saveFileName);     // 서버에 저장된 파일 이름
        }

        // DAO를 통해 DB에 게시 내용을 저장
        MVCBoardDAO dao = new MVCBoardDAO();
        int result = dao.insertWrite(dto);
        dao.close();

        // 성공 여부에 따른 처리
        if (result == 1) { // 글쓰기 성공
            resp.sendRedirect("../mvcboard/list.do");
        } else { // 글쓰기 실패
        	//글쓰기 페이지로 다시 돌아간다.
            JSFunction.alertLocation(resp, "글쓰기에 실패했습니다.", "../mvcboard/write.do");
        }
    }
}
