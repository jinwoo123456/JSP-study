package servlet;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/*
 * 서블릿 클래스를 만들기 위한 절차
 * 1. httpservlet 클래스를 상속한다.
 * 2. 클라이언트의 요청을 받아 처리하기 위한 doGet() / doPost() 메서드를
 *  오버라이딩한다.
 *  3. 서블릿에 필수적인 패키지와 임포트와 예외처리는 자동완성된다.
 *  4. request내장객체와 response내장객체는 매개변수를 통해 서블릿 클래스에 이미
 *  포함되어 있으므로 즉시 사용할 수 있다.
 * */
public class HelloServlet extends HttpServlet {
	
	
	
	/**
	 * 서블릿 작성시 발생되는 경고(warning)를 위해 추가하낟.
	 * 추가하지 않아도 실행에는 영향을 미치지 않는다.(교안에는 생략되어 있음)
	 */
	private static final long serialVersionUID = 1L;
	
	
	/*
	 * get방식의 요청을 처리하기 위한 doGet()메서드 오버라이딩
	 *만약 요청을 처리할 수 있는 메서드가 없으면 405에러가 발생하게 된다.
	 *(오버라이드는 엄마처럼 살기싫어(?) 같은거.)
	 * */
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		//request 영역에 속성을 저장한다.
		req.setAttribute("message", "Hello Servlet..!!");
		//Veiw에 해당하는 jsp로 포워드한다.
		req.getRequestDispatcher("/12Servlet/HelloServlet.jsp")
		.forward(req, resp);
		/*
		 * request 영역은 포워드된 페이지까지 공유되므로 서블릿에서 
		 * 저장한 속성은 jsp에서 사용할 수 있다.
		 * */
		// TODO Auto-generated method stub

	}
	
@Override
protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	// TODO Auto-generated method stub

}
}
